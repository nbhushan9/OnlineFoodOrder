<?php
session_start();

require_once './include/config.php';
require_once './include/db.class.php';

$db = new DB();

$mes = "";

$bRid = $_SESSION['b_rid'];

$selectCart = "SELECT SUM(ct_item_qty) AS cart_count FROM cart WHERE ct_b_rid = $bRid";

$cartCount = 0;

$cartItems = $db->executeSelect($selectCart);

if (count($cartItems) > 0) {
    $cartCount = $cartItems[0]['cart_count'];
}

$selectItems = "SELECT *, SUM(ct_item_qty) AS total_qty FROM cart"
        . " JOIN item ON(ct_item_rid = i_rid)"
        . " WHERE ct_b_rid = $bRid"
        . " GROUP BY ct_item_rid"
        . " ORDER BY i_name ASC";

$items = $db->executeSelect($selectItems);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
        ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <script>
<?php if (!empty($mes)) { ?>
            alert('<?php echo $mes; ?>');
<?php } ?>
    </script>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="#">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="view_cart_items.php">
                        <span class="icon">
                            <i class="fa fa-cart-plus"></i>
                        </span>
                        &nbsp;
                        Cart
                        &nbsp;
                        <label id="cartCount"><?php echo $cartCount; ?></label>
                    </a>
                    <a class="navbar-item" href="logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container is-fluid">
                    <table class="table" style="width: 100%;">
                        <thead>
                            <tr>
                                <th>Sl. No</th>
                                <th>Item Name</th>
                                <th>Price (per Kg)</th>
                                <th>Qty</th>
                                <th style="text-align: end;">Total (Qty * Price)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            $grandTotal = 0;
                            foreach ($items as $row) {
                                ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $row['i_name']; ?></td>
                                    <td><?php echo $row['i_price']; ?></td>
                                    <td><?php echo $row['total_qty']; ?></td>
                                    <td style="text-align: end;"><?php echo ($row['i_price'] * $row['total_qty']); ?></td>
                                </tr>
                                <?php
                                $grandTotal += ($row['i_price'] * $row['total_qty']);
                                $i++;
                            }
                            ?>
                            <tr>
                                <td colspan="4">Grand Total</td>
                                <td style="text-align: end; font-weight: bold;">
                                    <?php echo $grandTotal; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="5" style="text-align: end;">
                                    <a href="buy_item.php" class="button is-primary is-outlined">
                                        Checkout
                                    </a>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                       
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>ONLINE FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>

        <script type="text/javascript">

        </script>
    </body>
</html>
