<?php
require_once './session.php';
require_once './include/config.php';
require_once './include/db.class.php';

$db = new DB();

$mes = "";

$bRid = $_SESSION['b_rid'];

$selectCart = "SELECT SUM(ct_item_qty) AS cart_count FROM cart WHERE ct_b_rid = $bRid";

$cartCount = 0;

$cartItems = $db->executeSelect($selectCart);

if (count($cartItems) > 0) {
    $cartCount = $cartItems[0]['cart_count'];
}

$selectItems = "SELECT *, SUM(ct_item_qty) AS total_qty FROM cart"
        . " JOIN item ON(ct_item_rid = i_rid)"
        . " WHERE ct_b_rid = $bRid"
        . " GROUP BY ct_item_rid";

$items = $db->executeSelect($selectItems);

$grandTotal = 0;

$itemIds = "";
$qtys = "";
$sellerRids = "";

foreach ($items as $row) {
    $itemIds .= $row['ct_item_rid'] . ',';
    $qtys .= $row['ct_item_qty'] . ',';
    $sellerRids .= $row['i_seller_rid'] . ',';
    $grandTotal += ($row['total_qty'] * $row['i_price']);
}

if (!empty($itemIds)) {
    $itemIds = rtrim($itemIds, ",");
}

if (!empty($qtys)) {
    $qtys = rtrim($qtys, ",");
}

if (!empty($sellerRids)) {
    $sellerRids = rtrim($sellerRids, ",");
}

if (isset($_POST['btnConfirm'])) {
    $ids = $_POST['ids'];
    $qty = $_POST['qty'];
    $sellers = $_POST['sellers'];
    $address = $_POST['address'];

    $idsArray = explode(",", $ids);
    $qtyArray = explode(",", $qty);
    $sellerArray = explode(",", $sellers);


    for ($i = 0; $i < sizeof($idsArray); $i++) {
        $sql = "INSERT INTO `order`(o_buyer_rid, o_buyer_address, o_item_rid, o_total_qty, o_seller_rid)"
                . " VALUES($bRid, '$address', $idsArray[$i], $qtyArray[$i], $sellerArray[$i]) ";
        $j = $db->executeInsertAndGetId($sql);

        $deleteCart = "DELETE FROM cart WHERE ct_item_rid = $idsArray[$i] AND ct_b_rid = $bRid";

        $k = $db->executeUpdate($deleteCart);
    }

    header("location: buyer_home.php");
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Hopcoms
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="view_cart_items.php">
                        <span class="icon">
                            <i class="fa fa-cart-plus"></i>
                        </span>
                        &nbsp;
                        Cart
                        &nbsp;
                        <label id="cartCount"><?php echo $cartCount; ?></label>
                    </a>
                    <a class="navbar-item" href="logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container">
                    <div class="columns">
                        <div class="column is-5">
                            <form action="#" method="post" >

                                <input type="hidden" name="ids" value="<?php echo $itemIds; ?>"/>
                                <input type="hidden" name="qty" value="<?php echo $qtys; ?>"/>
                                <input type="hidden" name="sellers" value="<?php echo $sellerRids; ?>"/>

                                <div class="column">
                                    <div class="field">
                                        <label class="label">Total Amount (in Rs.)</label>
                                        <div class="control">
                                            <input class="input" type="text" name="totalAmount" id="totalAmount"
                                                   autocomplete="off" value="<?php echo $grandTotal; ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Card Number</label>
                                        <div class="control">
                                            <input class="input" type="text" name="cardNumber" id="cardNumber" maxlength="12"
                                                   placeholder="Enter Debit/Credit Card Number" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Delivery Address</label>
                                        <div class="control">
                                            <textarea class="textarea" type="text" name="address" id="address"
                                                      placeholder="Enter Address" autocomplete="off"></textarea>
                                        </div>
                                    </div>
                                    <div class="field">
                                        <div class="control has-text-centered">
                                            <button type="submit" name="btnConfirm"
                                                    class="button is-success is-outlined login-button">
                                                Confirm
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        <
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>