<?php
require_once '../include/config.php';
require_once '../include/db.class.php';

$db = new DB();

$mes = "";

$selectItems = "SELECT * FROM item"
        . " WHERE i_qty > 0"
        . " ORDER BY i_name ASC";

$items = $db->executeSelect($selectItems);
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
        ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="../assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="../assets/css/custom.css"/>
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css"/>
    </head>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="../aboutus.php">
                        About Us
                    </a>
                    <a class="navbar-item" href="../contactus.php">
                        Contact Us
                    </a>
                    <a class="navbar-item" href="login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="registration.php">
                        Register
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container is-fluid">
                    <div class="columns is-multiline">
                        <?php
                        foreach ($items as $row) {
                            ?>
                            <div class="column is-one-quarter">
                                <div class="card">
                                    <div class="card-image">
                                        <figure class="image is-4by3">
                                            <img src="<?php echo $row['i_img_url']; ?>" alt="Placeholder image">
                                        </figure>
                                    </div>
                                    <div class="card-content">
                                        <div class="media">
                                            <div class="media-content">
                                                <p class="title is-4"><?php echo $row['i_name']; ?></p>
                                            </div>
                                        </div>
                                        <div class="content">
                                            <p>
                                                Total Quantity :  <?php echo $row['i_qty']; ?> 
                                            </p>
                                            <p>
                                                Price : Rs. <?php echo $row['i_price']; ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
