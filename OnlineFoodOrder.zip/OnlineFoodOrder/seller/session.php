<?php

session_start();

if (!isset($_SESSION['s_rid'])) {
    header('location: index.php');
    die();
}
