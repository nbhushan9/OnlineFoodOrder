<?php
session_start();

require_once '../include/config.php';
require_once '../include/db.class.php';

$db = new DB();

$mes = "";

if (isset($_POST['btnRegister'])) {
    $name = $_POST['name'];
    $loginId = $_POST['loginId'];
    $password = $_POST['password'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    $insertSeller = "INSERT INTO seller(s_name, s_login_id, s_password, s_contact, s_email, s_address)"
            . " VALUES('$name', '$loginId', '$password', '$contact', '$email', '$address')";

    $id = $db->executeInsertAndGetId($insertSeller);

    if ($id > 0) {
        $mes = "Registered Successfully...";
    } else {
        $mes = "Something went wrong... Please try again.";
    }
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
        ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="../assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="../assets/css/custom.css"/>
        <link rel="stylesheet" href="../assets/css/font-awesome.min.css"/>
    </head>
    <script>
<?php if (!empty($mes)) { ?>
            alert('<?php echo $mes; ?>');
<?php } ?>
    </script>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="../aboutus.php">
                        About Us
                    </a>
                    <a class="navbar-item" href="../contactus.php">
                        Contact Us
                    </a>
                    <a class="navbar-item" href="login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="registration.php">
                        Register
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container">
                    <div class="columns">
                        <div class="column is-5">
                            <form action="#" method="post" onsubmit="return validateRegistrationForm();">
                                <div class="column">
                                    <div class="field">
                                        <label class="label">Name</label>
                                        <div class="control">
                                            <input class="input" type="text" name="name" id="name"
                                                   placeholder="Enter Full Name" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Login ID</label>
                                        <div class="control">
                                            <input class="input" type="text" name="loginId" id="loginId"
                                                   placeholder="Enter Login ID" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Password</label>
                                        <div class="control">
                                            <input class="input" type="password" name="password" id="password"
                                                   placeholder="Enter Password" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Contact Number</label>
                                        <div class="control">
                                            <input class="input" type="text" name="contact" id="contact"
                                                   placeholder="Enter Contact Number" maxlength="10" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Email ID</label>
                                        <div class="control">
                                            <input class="input" type="text" name="email" id="email"
                                                   placeholder="Enter Email ID" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Address</label>
                                        <div class="control">
                                            <textarea class="textarea" type="text" name="address" id="address"
                                                      placeholder="Enter Address" autocomplete="off"></textarea>
                                        </div>
                                    </div>
                                    <div class="field">
                                        <div class="control has-text-centered">
                                            <button type="submit" name="btnRegister"
                                                    class="button is-success is-outlined login-button">
                                                Register
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
