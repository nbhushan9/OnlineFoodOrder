<?php
require_once './session.php';
require_once './include/config.php';
require_once './include/db.class.php';

$db = new DB();

$mes = "";

$bRid = $_SESSION['b_rid'];

$selectCart = "SELECT SUM(ct_item_qty) AS cart_count FROM cart WHERE ct_b_rid = $bRid";

$cartCount = 0;

$cartItems = $db->executeSelect($selectCart);

if (count($cartItems) > 0) {
    $cartCount = $cartItems[0]['cart_count'];
}

if (isset($_POST['btnAddToCart'])) {
    $itemRid = $_POST['itemRid'];
    $itemQty = $_POST['itemQty'];

    $insertToCart = "INSERT INTO cart(ct_b_rid, ct_item_rid, ct_item_qty)"
            . " VALUES($bRid, $itemRid, $itemQty)";

    $i = $db->executeInsertAndGetId($insertToCart);

    if ($i > 0) {
        header("location: buyer_home.php");
    } else {
        $mes = "Something went wrong";
    }
} else if (isset($_GET['item_rid']) && isset($_GET['seller_rid'])) {
    $itemRid = $_GET['item_rid'];
    $sellerRid = $_GET['seller_rid'];

    $selectItem = "SELECT * FROM item WHERE i_rid = $itemRid AND i_seller_rid = $sellerRid";

    $item = $db->executeSelect($selectItem)[0];
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <script>
<?php if (!empty($mes)) { ?>
            alert('<?php echo $mes; ?>');
<?php } ?>
    </script>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="view_cart_items.php">
                        <span class="icon">
                            <i class="fa fa-cart-plus"></i>
                        </span>
                        &nbsp;
                        Cart
                        &nbsp;
                        <label id="cartCount"><?php echo $cartCount; ?></label>
                    </a>
                    <a class="navbar-item" href="logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container">
                    <div class="columns">
                        <div class="column is-5">
                            <form action="#" method="post" >
                                <input type="hidden" name="itemRid" value="<?php echo $itemRid; ?>"/>
                                <div class="column">
                                    <div class="field">
                                        <label class="label">Item Name</label>
                                        <div class="control">
                                            <input class="input" type="text" name="itemName" id="itemName"
                                                   autocomplete="off" value="<?php echo $item['i_name']; ?>">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Enter Quantity</label>
                                        <div class="control">
                                            <input class="input" type="number" min="1" max="<?php echo $item['i_qty']; ?>"
                                                   name="itemQty" id="itemQty"
                                                   placeholder="Enter Quantity" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <div class="control has-text-centered">
                                            <button type="submit" name="btnAddToCart"
                                                    class="button is-success is-outlined login-button">
                                                Add
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        <p>
                            
                        </p>
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        <p>
                            )
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>