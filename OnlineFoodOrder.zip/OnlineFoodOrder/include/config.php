<?php

// database configurations
define('localhost', 'localhost');
define('root', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'hopcoms');

?>

