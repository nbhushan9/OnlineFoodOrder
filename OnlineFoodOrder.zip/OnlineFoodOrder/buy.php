<?php

require_once './config.php';
require_once './db.class.php';

$db = new DB();

$mes = "";
if (isset($_POST['btnConfirm'])) {
    $itemRid = $_POST['itemRid'];
    $sellerRid = $_POST['sellerRid'];
    $buyerName = $_POST['name'];
    $buyerAddress = $_POST['address'];
    $buyerContact = $_POST['contact'];
    $buyerEmail = $_POST['email'];
    $itemQty = $_POST['itemQty'];

    $insertOrder = "INSERT INTO `order`(o_buyer_name, o_buyer_address, o_buyer_contact, o_buyer_email, o_item_rid, o_total_qty, o_seller_rid)"
            . " VALUES('$buyerName', '$buyerAddress', '$buyerContact', '$buyerEmail', '$itemRid', '$itemQty', '$sellerRid')";

    $rid = $db->executeInsertAndGetId($insertOrder);

    if ($rid > 0) {
        $updateQty = "UPDATE item SET i_qty = (i_qty - $itemQty) WHERE i_rid = $itemRid";
        $db->executeUpdate($updateQty);
    }

    header("location: view_items.php");
}