<?php
require_once './session.php';
require_once './config.php';
require_once './db.class.php';
require_once './util.php';

$db = new DB();

$mes = "";

$uRid = $_SESSION['s_rid'];

if (isset($_FILES['photo'])) {
    $photoUrl = uploadFile('photo');
    $itemName = $_POST['itemName'];
    $itemQty = $_POST['itemQty'];
    $itemPrice = $_POST['itemPrice'];

    $insertSeller = "INSERT INTO item(i_name, i_qty, i_price, i_seller_rid, i_img_url)"
            . " VALUES('$itemName', '$itemQty', '$itemPrice', '$uRid', '$photoUrl')";

    $id = $db->executeInsertAndGetId($insertSeller);

    if ($id > 0) {
        $mes = "Inserted Successfully...";
    } else {
        $mes = "Something went wrong... Please try again.";
    }
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
            ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <script>
<?php if (!empty($mes)) { ?>
            alert('<?php echo $mes; ?>');
<?php } ?>
    </script>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="add_items.php">
                        Add Items
                    </a>
                    <a class="navbar-item" href="seller_home.php">
                        View Items
                    </a>
                    <a class="navbar-item" href="view_orders.php">
                        View Orders
                    </a>
                    <a class="navbar-item" href="login.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container">
                    <div class="columns">
                        <div class="column is-5">
                            <form action="#" method="post" onsubmit="return validateAddItem();" enctype="multipart/form-data">
                                <div class="column">
                                    <div class="field">
                                        <label class="label">Item Name</label>
                                        <label class="file-label">
                                            <input class="file-input" type="file" name="photo" id="photo">
                                            <span class="file-cta">
                                                <span class="file-label">
                                                    Choose a file…
                                                </span>
                                            </span>
                                        </label>
                                    </div>
                                    <div class="field">
                                        <label class="label">Item Name</label>
                                        <div class="control">
                                            <input class="input" type="text" name="itemName" id="itemName"
                                                   placeholder="Enter Item Name" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Item Quantity</label>
                                        <div class="control">
                                            <input class="input" type="number" name="itemQty" id="itemQty"
                                                   placeholder="Enter Item Quantity" min="1"
                                                   autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <label class="label">Item Price</label>
                                        <div class="control">
                                            <input class="input" type="number" name="itemPrice" id="itemPrice"
                                                   min="1" max="1000"
                                                   placeholder="Enter Item Price" autocomplete="off">
                                        </div>
                                    </div>
                                    <div class="field">
                                        <div class="control has-text-centered">
                                            <button type="submit" name="btnAddItems" id="btnAddItems"
                                                    class="button is-success is-outlined login-button">
                                                Add Item
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        <p>
                           
                        </p>
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        <p>
                            Horticultural Producers Co-operative Marketing and Processing Society Limited (HOPCOMS)
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
