/*
SQLyog Enterprise - MySQL GUI v8.12 
MySQL - 5.7.23-log : Database - hopcoms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`hopcoms` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `hopcoms`;

/*Table structure for table `admins` */

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` int(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admins` */

insert  into `admins`(`id`,`email`,`pass`) values (1,'admin','pass');

/*Table structure for table `buyer` */

DROP TABLE IF EXISTS `buyer`;

CREATE TABLE `buyer` (
  `bu_rid` int(11) NOT NULL AUTO_INCREMENT,
  `bu_name` varchar(50) DEFAULT NULL,
  `bu_login_id` varchar(25) DEFAULT NULL,
  `bu_password` varchar(50) DEFAULT NULL,
  `bu_contact` char(10) DEFAULT NULL,
  `bu_email` varchar(75) DEFAULT NULL,
  `bu_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bu_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `buyer` */

insert  into `buyer`(`bu_rid`,`bu_name`,`bu_login_id`,`bu_password`,`bu_contact`,`bu_email`,`bu_address`) values (1,'Buyer One','buyerone','1234','9876543210','buyer1@gmail.com','ajskladsfksdjafjfdjsdffds');

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `ct_rid` int(11) NOT NULL AUTO_INCREMENT,
  `ct_b_rid` int(11) DEFAULT NULL,
  `ct_item_rid` int(11) DEFAULT NULL,
  `ct_item_qty` int(11) DEFAULT NULL,
  PRIMARY KEY (`ct_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

insert  into `cart`(`ct_rid`,`ct_b_rid`,`ct_item_rid`,`ct_item_qty`) values (4,1,1,2);

/*Table structure for table `item` */

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `i_rid` int(11) NOT NULL AUTO_INCREMENT,
  `i_name` varchar(50) DEFAULT NULL,
  `i_qty` int(11) DEFAULT '0',
  `i_price` float DEFAULT NULL,
  `i_seller_rid` int(11) DEFAULT NULL,
  `i_img_url` text,
  PRIMARY KEY (`i_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `item` */

insert  into `item`(`i_rid`,`i_name`,`i_qty`,`i_price`,`i_seller_rid`,`i_img_url`) values (1,'sdfsdf',12,57,1,'uploads/2609861845be56ce625f82.jpg'),(2,'sdfsfd',30,23,1,'uploads/2609861845be56ce625f82.jpg');

/*Table structure for table `order` */

DROP TABLE IF EXISTS `order`;

CREATE TABLE `order` (
  `o_rid` int(11) NOT NULL AUTO_INCREMENT,
  `o_buyer_rid` int(11) DEFAULT NULL,
  `o_buyer_address` varchar(250) DEFAULT NULL,
  `o_item_rid` int(11) DEFAULT NULL,
  `o_total_qty` int(11) DEFAULT NULL,
  `o_seller_rid` int(11) DEFAULT NULL,
  PRIMARY KEY (`o_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `order` */

insert  into `order`(`o_rid`,`o_buyer_rid`,`o_buyer_address`,`o_item_rid`,`o_total_qty`,`o_seller_rid`) values (1,1,'sdfsdfsfd',1,2,1),(2,1,'sdfsdfsfd',2,3,1);

/*Table structure for table `seller` */

DROP TABLE IF EXISTS `seller`;

CREATE TABLE `seller` (
  `s_rid` int(11) NOT NULL AUTO_INCREMENT,
  `s_name` varchar(50) DEFAULT NULL,
  `s_login_id` varchar(25) DEFAULT NULL,
  `s_password` varchar(100) DEFAULT NULL,
  `s_contact` char(10) DEFAULT NULL,
  `s_email` varchar(75) DEFAULT NULL,
  `s_address` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`s_rid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `seller` */

insert  into `seller`(`s_rid`,`s_name`,`s_login_id`,`s_password`,`s_contact`,`s_email`,`s_address`) values (1,'Farmer 1','farmer1','1234','9876543210','farmer1@gmail.com','sdfdsf');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
