<?php
require_once './include/config.php';
require_once './include/db.class.php';

$db = new DB();

$mes = "";
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
        ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/bulma-carousel.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="aboutus.php">
                        About Us
                    </a>
                    <a class="navbar-item" href="contactus.php">
                        Contact Us
                    </a>
                    <a class="navbar-item" href="buyer_login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="buyer_registration.php">
                        Register
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <section class="hero is-fullheight">
            <div class="hero-body">
                <div class="container is-fluid">
                    <div class='carousel carousel-animated carousel-animate-slide'>
                        <div class='carousel-container'>
                            <div class='carousel-item has-background is-active'>
                                <img class="is-background" src="2.jpg" alt="" width="640" height="310" />
                            </div>
                            <div class='carousel-item has-background'>
                                <img class="is-background" src="burger-cropped.jpg" alt="" width="640" height="310" />
                            </div>
                            <div class='carousel-item has-background'>
                                <img class="is-background" src="food processing_0.jpg" alt="" width="640" height="310" />
                            </div>
                            <div class='carousel-item has-background'>
                                <img class="is-background" src="junk-food.jpg" alt="" width="640" height="310" />
                            </div>
                        </div>
                        <div class="carousel-navigation is-overlay">
                            <div class="carousel-nav-left">
                                <i class="fa fa-chevron-left" aria-hidden="true"></i>
                            </div>
                            <div class="carousel-nav-right">
                                <i class="fa fa-chevron-right" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        <p>
                            Horticultural Producers Co-operative Marketing and Processing Society Limited (HOPCOMS)
                        </p>
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        <p>
                            
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/bulma-carousel.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
