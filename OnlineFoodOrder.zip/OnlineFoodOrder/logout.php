<?php

session_start();

session_destroy();

unset($_SESSION['b_rid']);

header('location: index.php');
die();

