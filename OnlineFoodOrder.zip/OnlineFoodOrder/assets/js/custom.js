$(document).ready(function () {
    var carousels = bulmaCarousel.attach();
});

function validateLoginForm() {
    var loginId = $("#loginId").val();
    var password = $("#password").val();

    if (loginId === "") {
        alert("Please enter login ID");
        return false;
    }

    if (password === "") {
        alert("Please enter passsword");
        return false;
    }

    return true;
}

function validateRegistrationForm() {
    var name = $('#name').val();
    var loginId = $('#loginId').val();
    var password = $('#password').val();
    var contact = $('#contact').val();
    var email = $('#email').val();
    var address = $('#address').val();

    if (name === "") {
        alert("Please enter name");
        return false;
    }

    if (loginId === "") {
        alert("Please enter login ID");
        return false;
    }

    if (password === "") {
        alert("Please enter password");
        return false;
    }

    if (contact === "" || contact.length !== 10) {
        alert("Please enter valid 10 digits contact number");
        return false;
    }

    if (email === "") {
        alert("Please enter email ID");
        return false;
    }

    if (address === "") {
        alert("Please enter address");
        return false;
    }

    return true;
}

function  validateAddItem() {
    var photo = $('#photo').val();
    var itemName = $('#itemName').val();
    var itemQty = $('#itemQty').val();
    var itemPrice = $('#itemPrice').val();

    if (photo === "") {
        alert("Please select photo");
        return false;
    }

    if (itemName === "") {
        alert("Please enter item name");
        return false;
    }

    if (itemQty === "") {
        alert("Please enter quantity");
        return false;
    }

    if (itemPrice === "") {
        alert("Please enter price");
        return false;
    }

    return true;
}

function validateBuyItem() {
    var name = $("#name").val();
    var contact = $("#contact").val();
    var email = $("#email").val();
    var address = $("#address").val();
    var itemQty = $("#itemQty").val();

    if (name === "") {
        alert("Please enter name");
        return false;
    }

    if (contact === "" || contact.length !== 10) {
        alert("Please enter valid 10 digits contact number");
        return false;
    }

    if (email === "") {
        alert("Please enter email ID");
        return false;
    }

    if (address === "") {
        alert("Please enter address");
        return false;
    }

    if (itemQty === "" || itemQty <= 0) {
        alert("Invalid quantity");
        return false;
    }

    return true;
}

function addToCart(itemRid, sellerRid, buyerRid) {
    $.ajax({
        url: "add_to_cart.php",
        type: 'POST',
        data: {
            itemRid: itemRid,
            sellerRid: sellerRid,
            buyerRid: buyerRid
        },
        success: function (data, textStatus, jqXHR) {

        },
        error: function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        }
    });
}