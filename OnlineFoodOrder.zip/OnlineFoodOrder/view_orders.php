<?php
require_once './session.php';

require_once './config.php';
require_once './db.class.php';

$db = new DB();

$mes = "";

$uRid = $_SESSION['s_rid'];

$selectItems = " SELECT * FROM `order`"
        . " JOIN item ON(o_item_rid = i_rid)"
        . " WHERE o_seller_rid = 1"
        . " ORDER BY i_name ASC";

$items = $db->executeSelect($selectItems);
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title>
        ONLINE FOOD ORDERING
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="add_items.php">
                        Add Items
                    </a>
                    <a class="navbar-item" href="seller_home.php">
                        View Items
                    </a>
                    <a class="navbar-item" href="view_orders.php">
                        View Orders
                    </a>
                    <a class="navbar-item" href="logout.php">
                        Logout
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <br/>
        <br/>
        <section class="hero">
            <div class="hero-body">
                <div class="container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sl. No</th>
                                <th>Item Name</th>
                                <th>Buyer Name</th>
                                <th>Contact</th>
                                <th>Address</th>
                                <th>Order Qty.</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            foreach ($items as $row) {
                                ?>
                                <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?php echo $row['i_name'] ?></td>
                                    <td><?php echo $row['o_buyer_name'] ?></td>
                                    <td><?php echo $row['o_buyer_contact'] ?></td>
                                    <td><?php echo $row['o_buyer_address'] ?></td>
                                    <td><?php echo $row['o_total_qty'] ?></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                       
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
