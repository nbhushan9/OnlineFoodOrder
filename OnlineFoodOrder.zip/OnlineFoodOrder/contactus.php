<html>
    <head>
        <meta charset="UTF-8">
        <title>
            Hopcoms
        </title>
        <link rel="stylesheet" href="assets/css/bulma.min.css"/>
        <link rel="stylesheet" href="assets/css/custom.css"/>
        <link rel="stylesheet" href="assets/css/font-awesome.min.css"/>
    </head>
    <body>
        <nav class="navbar is-fixed-top" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <i class="fa fa-tree"></i>&nbsp;ONLINE FOOD ORDERING
                </a>

                <a role="button" class="navbar-burger burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-end">
                    <a class="navbar-item" href="index.php">
                        Home
                    </a>
                    <a class="navbar-item" href="aboutus.php">
                        About Us
                    </a>
                    <a class="navbar-item" href="contactus.php">
                        Contact Us
                    </a>
                    <a class="navbar-item" href="buyer_login.php">
                        Login
                    </a>
                    <a class="navbar-item" href="buyer_registration.php">
                        Register
                    </a>
                </div>
            </div>
        </nav>
        <br/>
        <br/>
        <br/>
        <section class="hero">
            <div class="hero-body">
                <div class="container">
                    <h1 class="title">
                        Contact US
                    </h1>
                    <h2 class="subtitle">
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                    </h2>
                </div>
            </div>
        </section>
        <footer class="footer">
            <div class="content">
                <div class="columns">
                    <div class="column is-4">
                        <h3>About Us</h3>
                        
                    </div>
                    <div class="column is-4">
                        <h3>Contact Us</h3>
                        
                        <p>
                            <span class="icon">
                                <i class="fa fa-home"></i>
                            </span>
                            Lalbagh, Bangalore – 560004
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-phone"></i>
                            </span>
                            Tel.: 080- 26577552 / 080-26572832
                        </p>
                        <p>
                            <span class="icon">
                                <i class="fa fa-fax"></i>
                            </span>
                            Fax: 26579017
                        </p>
                    </div>
                </div>
                <br/>
                <div class="content">
                    <p class="has-text-centered">
                        &copy; <?php echo date("Y"); ?>  <strong>FOOD ORDERING</strong>
                    </p>
                </div>
            </div>
        </footer>

        <script src="assets/js/jquery-3.3.1.min.js"></script>
        <script src="assets/js/custom.js"></script>
    </body>
</html>
